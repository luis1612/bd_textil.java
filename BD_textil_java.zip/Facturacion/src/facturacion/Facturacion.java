/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package facturacion;


public class Facturacion {

    public static void main(String[] args) {
       new Interfaz_principal().setVisible(true);
    }

   
}
